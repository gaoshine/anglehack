/** Automatically generated file. DO NOT MODIFY */
package mobi.c365.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}