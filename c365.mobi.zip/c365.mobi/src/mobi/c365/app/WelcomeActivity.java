package mobi.c365.app;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Intent;
import android.view.Window;
import android.view.WindowManager;

public class WelcomeActivity extends Activity {
	private Handler mHandler;

    @Override
    public void onCreate(Bundle savedInstanceState) {
		//ȫ����ʾ
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);//ȥ��״̬��
        setContentView(R.layout.welcome);
        mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {
			public void run() {
				login();
			}
		}, 3000);

    }


	public void login(){
		Intent intent=new Intent(this,LoginActivity.class );
		startActivity(intent);
		finish();
	}


    
}
