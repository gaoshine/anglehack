package mobi.c365.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


/**
 * @author gaoshine
 * 
 */
public class LoginActivity extends Activity implements OnClickListener {
	private Button mBtnLogin;
	private View mMoreView;// �������¼ѡ���view
	private View mMoreMenuView;// �������¼ѡ��е�����view
	private Button mButton1;
	private ImageView mMoreImage;// �������¼ѡ��ļ�ͷͼƬ
	private EditText mAccounts, mPassword;
	private boolean mShowMenu = false;// �������¼ѡ��������Ƿ���ʾ

	public void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState); // ִ�и����onCreate
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);// ȥ��״̬��

		setContentView(R.layout.login); // ��Attivity��Ӧ����Ӧ�Ľ�����
										// res/layout/��Ӧ����.xml (welcome.xml)

		mAccounts = (EditText) findViewById(R.id.lgoin_accounts);
		mPassword = (EditText) findViewById(R.id.login_password);

		mBtnLogin = (Button) findViewById(R.id.login_btn);
		mBtnLogin.setOnClickListener(this);

		mMoreView = findViewById(R.id.more);
		mMoreView.setOnClickListener(this);

		mMoreMenuView = findViewById(R.id.moremenu);

		mMoreImage = (ImageView) findViewById(R.id.more_image);

		mButton1 = (Button) findViewById(R.id.button1);
		mButton1.setOnClickListener(this);

		readPara();
	}

	public void onRestart() {
		super.onRestart();
		readPara();
	}

	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.login_btn:
			if (isNetworkAvailable()) {
				String my = mAccounts.getText().toString();

				if (my.length() < 1) {
					Toast toast = Toast.makeText(LoginActivity.this,
							"�û��ʺŲ���Ϊ�գ�", Toast.LENGTH_SHORT);
					toast.show();
					return;
				}
				goMainActivity();

			} else {

				toast();

			}

			break;
		case R.id.button1:
			goRegisterActivity();
			break;

		case R.id.more:
			if (!mShowMenu) {
				mMoreMenuView.setVisibility(View.VISIBLE);
				mMoreImage.setImageResource(R.drawable.login_more);
				mShowMenu = true;
			} else {
				mMoreMenuView.setVisibility(View.GONE);
				mMoreImage.setImageResource(R.drawable.login_more_up);
				mShowMenu = false;

			}
			break;

		}

	}

	private void toast() {

		new AlertDialog.Builder(LoginActivity.this)
				.setTitle("���÷�����")
				.setMessage("������������δ��")
				.setPositiveButton("ǰ����",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								Intent intent = new Intent(
										android.provider.Settings.ACTION_WIRELESS_SETTINGS);
								startActivity(intent);
							}
						}).setNegativeButton("ȡ��", null).create().show();
	}

	/**
	 * ����ע�����
	 */
	public void goRegisterActivity() {
		Intent intent = new Intent();
		intent.setClass(this, RegisterActivity.class);
		startActivity(intent);
	}

	/**
	 * ����������
	 */
	public void goMainActivity() {
		Intent intent = new Intent();
		intent.setClass(this, MainActivity.class);
		startActivity(intent);

	}

	// �Ӳ�����ȡ�����ļ�
	private void readPara() {
		SharedPreferences pre = getSharedPreferences("k3_kingstar",
				MODE_WORLD_READABLE);
		String myname = pre.getString("myname", "");
		String myserver = pre.getString("myserver", "");
		String mypwd = pre.getString("mypwd", "");
		String myzhangtao = pre.getString("myzhangtao", "");

		mAccounts.setText(myname);
		mPassword.setText(mypwd);
	}

	/**
	 * �ж��ֻ������Ƿ����
	 * 
	 * @param context
	 * @return
	 */
	private boolean isNetworkAvailable() {
		ConnectivityManager mgr = (ConnectivityManager) getApplicationContext()
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo[] info = mgr.getAllNetworkInfo();
		if (info != null) {
			for (int i = 0; i < info.length; i++) {
				if (info[i].getState() == NetworkInfo.State.CONNECTED) {
					return true;
				}
			}
		}
		return false;
	}

	public void onBackPressed() {// ���񷵻ذ���
		exitDialog(LoginActivity.this, "��ʾ", "�����Ҫ�˳���");
	}


	/**
	 * �˳�ʱ����ʾ��
	 * 
	 * @param context
	 *            �����Ķ���
	 * @param title
	 *            ����
	 * @param msg
	 *            ����
	 */
	private void exitDialog(Context context, String title, String msg) {
		new AlertDialog.Builder(context).setTitle(title).setMessage(msg)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				}).setNegativeButton("ȡ��", null).create().show();
	}


}
