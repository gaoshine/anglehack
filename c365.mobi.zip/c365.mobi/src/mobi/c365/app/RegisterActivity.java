package mobi.c365.app;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("WorldWriteableFiles")
public class RegisterActivity extends Activity implements OnClickListener {
	private Button register_btn;
	private Button reg_back_btn;
	private Button registercls_btn;
	private EditText reg_server;
	private EditText reg_name;	
	private EditText reg_password;
	private EditText reg_zhangtao;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);//ȥ��״̬��
        setContentView(R.layout.register);
        
        register_btn=(Button)findViewById(R.id.register_btn );
        reg_back_btn=(Button)findViewById(R.id.reg_back_btn  );
        registercls_btn=(Button)findViewById(R.id.registercls_btn  );

        reg_server=(EditText)findViewById(R.id.reg_server  );
        reg_name=(EditText)findViewById(R.id.reg_name  );
        reg_password=(EditText)findViewById(R.id.reg_password  );
        reg_zhangtao=(EditText)findViewById(R.id.reg_zhangtao);
        
        register_btn.setOnClickListener(this);
        reg_back_btn.setOnClickListener(this);
        registercls_btn.setOnClickListener(this);
        
        readPara();
    }



	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
    	switch (v.getId()){
    	case R.id.register_btn:
    		writePara();
    		finish();
    		break;	
    	case R.id.registercls_btn:
    		clsPara();
    		writePara();
    		break;
    	case R.id.reg_back_btn:
    		finish();
    		break;	
    	}
	}  

	//�Ѳ���д�������ļ�
	private void writePara(){
    	SharedPreferences.Editor editor =  getSharedPreferences("k3_kingstar",MODE_WORLD_WRITEABLE).edit(); 
    	editor.putString("myname",reg_name.getText().toString() );
    	editor.putString("myserver",reg_server.getText().toString() );
    	editor.putString("mypwd",reg_password.getText().toString() );
     	editor.putString("myzhangtao",reg_zhangtao.getText().toString() );
    	editor.commit();
    	Toast toast = Toast.makeText(RegisterActivity.this, "�����Ѿ����棡", Toast.LENGTH_SHORT); 
    	toast.show(); 
    }

	
	//�Ӳ�����ȡ�����ļ�    
	private void readPara(){
        SharedPreferences pre = getSharedPreferences("k3_kingstar",MODE_WORLD_READABLE );
        String myname=pre.getString("myname", "");
        String myserver=pre.getString("myserver", "");
        String mypwd=pre.getString("mypwd", "");
        String myzhangtao=pre.getString("myzhangtao", "");
        reg_name.setText(myname);
        reg_server.setText(myserver);
        reg_password.setText(mypwd);
        reg_zhangtao.setText(myzhangtao);
	}
	
	//�������
	private void clsPara(){
        reg_name.setText("");
        reg_server.setText("");
        reg_password.setText("");
       	Toast toast = Toast.makeText(RegisterActivity.this, "�����Ѿ������", Toast.LENGTH_SHORT); 
    	toast.show(); 
 		
	}
    
}
