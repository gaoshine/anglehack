<!DOCTYPE html>
<html>
	<head>

	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title> By Gaoshine</title>
	<link rel="stylesheet" href="lib/jquery.mobile-1.0a4.1.min.css" />
	<script src="lib/jquery-1.5.min.js"></script>
	<script src="lib/jquery.mobile-1.0a4.1.min.js"></script>
	<script src="utils.js"></script>
	</head>
