<?php
print "<div data-role=\"footer\" class=\"ui-bar\">";
print "<a href=\"index.php\" data-role=\"button\" data-icon=\"home\">首页</a>";

?>

